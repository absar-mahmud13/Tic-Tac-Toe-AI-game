# CS50-AI-Tic-Tac-Toe
Implemented AI for tic tac toe game

Use python runner.py to play :)

Almost impossible to win :|
